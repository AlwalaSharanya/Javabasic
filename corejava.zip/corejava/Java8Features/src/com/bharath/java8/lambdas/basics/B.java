package com.bharath.java8.lambdas.basics;


@FunctionalInterface
public interface B extends A {
	
	void myMethod();
}
