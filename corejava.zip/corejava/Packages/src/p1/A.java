package p1;

public class A {
	
	public static void a1(){
		System.out.println("Inside a1");
	}
	
	public void a2(){
		System.out.println("Inside a2");
	}

}