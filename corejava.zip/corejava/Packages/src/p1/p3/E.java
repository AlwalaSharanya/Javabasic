package p1.p3;

public class E {

	public void e1(){
		System.out.println("Inside E1");
	}
}
