package com.homeinteriors.livingroom;

public class Sofa {

}
