package com.bharath.maven.mavendemo;

/**
 * Hello world!
 *
 */
public class App {

	public String hello(String name) {
		return "Hello " + name;
	}

}
