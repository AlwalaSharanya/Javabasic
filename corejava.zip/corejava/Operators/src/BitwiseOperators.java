public class BitwiseOperators {

	public static void main(String[] args) {

		System.out.println(true & true);
		System.out.println(false | false);
		System.out.println(true ^ false);
		System.out.println(4&5);
		System.out.println(4|5);
		System.out.println(4^5);

	}

}
