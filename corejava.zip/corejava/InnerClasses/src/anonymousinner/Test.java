package anonymousinner;

public class Test {

	public static void main(String[] args) {

		Connection con = DriverManager.getConnection();
		con.createStatement();

	}

}
