package anonymousinner;

public interface Connection {

	void createStatement();
}
