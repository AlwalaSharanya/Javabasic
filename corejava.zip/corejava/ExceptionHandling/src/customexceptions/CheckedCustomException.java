package customexceptions;

public class CheckedCustomException extends Exception{
	
	CheckedCustomException(String message){
		super(message);
	}

}
