
public class Test {
	
	static ArrayIndexOOBDemo a;

	public static void main(String[] args) {
		
		Test.a.method1();

	}

}
