public class MACBookAir extends MACBook {

	@Override
	public void start() {
		System.out.println("Inside MACBookAir start Method");
	}

	@Override
	public void shutdown() {
		System.out.println("Inside MACBookAir shutdown Method");
	}
}
