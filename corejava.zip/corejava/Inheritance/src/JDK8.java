
public class JDK8 extends JDK7 {

	JDK8(){
		System.out.println("Instantiating JDK8");
	}
}
