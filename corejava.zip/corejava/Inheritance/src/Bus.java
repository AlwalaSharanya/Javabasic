
public class Bus extends Vehicle{

	String fuel(){
		return "CNG";
	}
}
