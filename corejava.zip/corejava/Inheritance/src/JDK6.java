
public class JDK6 {

	JDK6(){
		System.out.println("Instantiating JDK6");
	}
}
