package moreinheritanceconcepts;

public class Test {

	public static void main(String[] args) {
		
		Child c = new Child(40,50,10,20);
		//c.f1();
		c.displayDetails();

	}

}
