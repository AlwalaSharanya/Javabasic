package moreinheritanceconcepts;

public class FinalClass {
	
	final static float pi = 3.14f;
	
	final void method(){
		
	}

}
