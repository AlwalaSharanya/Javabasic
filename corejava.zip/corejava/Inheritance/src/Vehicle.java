
public class Vehicle {

	String fuel(){
		return "Petrol";
	}
}
