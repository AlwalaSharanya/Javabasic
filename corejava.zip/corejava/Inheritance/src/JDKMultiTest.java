
public class JDKMultiTest {

	public static void main(String[] args) {
		JDK8 jdk8 = new JDK8();

	}

}
