
public class Child extends Parent{
	
	Child(){
		System.out.println("Child Object "+this);
	}
	
	void f2(){
		System.out.println("Inside f2");
	}
}
