
public class JDK7 extends JDK6 {

	JDK7(){
		System.out.println("Instantiating JDK7");
	}
}
