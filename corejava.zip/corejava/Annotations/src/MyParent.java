public class MyParent {

	public String greet(String name) {
		return "Hello " + name;
	}
}
