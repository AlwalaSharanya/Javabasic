public class A {

	@Deprecated
	public void myMethod() {

	}

	public void myMethod2() {

	}
}
