
public class AnnotationTest {
	
	@MyAnnotation
	public void myMethod(){
		
	}

}
