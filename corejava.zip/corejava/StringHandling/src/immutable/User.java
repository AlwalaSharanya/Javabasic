package immutable;

public class User {

	int id;
	String name;

	User(int id, String name) {
		this.id = id;
		this.name = name;
	}

}
