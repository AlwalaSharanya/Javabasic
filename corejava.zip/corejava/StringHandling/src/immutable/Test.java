package immutable;

public class Test {

	public static void main(String[] args) {

		User user = new User(1, "John");
		System.out.println(user);
		
		String s = new String("Bharath");
		System.out.println(s);
		
		Integer i = new Integer(30);
		System.out.println(i);

	}

}
