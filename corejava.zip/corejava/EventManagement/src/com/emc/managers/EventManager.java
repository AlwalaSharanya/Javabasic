package com.emc.managers;

import com.emc.entities.Event;

public interface EventManager {

	Event create(Long id);

}
