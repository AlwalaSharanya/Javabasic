package com.emc.entities;

public class Organizer extends EMBase {

}
