public class IfElseDemo {

	public static void main(String[] args) {

		int x = 20, y = 10;

		if (x > y)
			System.out.println("X is greater");
		else if (y > x)
			System.out.println("Y is greater");
		else
			System.out.println("Bother the numbers are equal");

	}
}
