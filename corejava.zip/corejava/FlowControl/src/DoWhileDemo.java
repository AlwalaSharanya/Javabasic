public class DoWhileDemo {

	public static void main(String[] args) {
		int x = 1;

		do {
			System.out.println("Inside the loop");
		} while (x < 1);

	}

}
