
public class Constructors {

	public static void main(String[] args) {
		
		long l = 1000;
		Long a = new Long(l);
		
		String s ="2000";
		
		Long b = new Long(s);

	}

}
