public class FiveSeries extends BMW {

	@Override
	void accelerate() {
		System.out.println("Inside Five Series Accelerate method");

	}

	@Override
	void brake() {
		
	}

}
