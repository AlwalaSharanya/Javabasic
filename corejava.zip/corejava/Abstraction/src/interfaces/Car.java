package interfaces;

public interface Car {
	
	void go();
	void stop();

}
