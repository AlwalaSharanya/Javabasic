
public final class ThreeSeries extends BMW{

	@Override
	void accelerate() {
		
		System.out.println("Inside ThreeSeries accelerate()");
		
	}

	@Override
	void brake() {
		
	}

}
